package org.openstreetmap.gwt.client;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openstreetmap.josm.data.osm.DataSet;

import com.google.gwt.junit.client.GWTTestCase;

public class DataSetTest extends GWTTestCase{

	DataSet data;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		//data=new DataSet();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	

	@Test
	public void testGetHighlightUpdateCount() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetVersion() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetVersion() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetNodes() {
		fail("Not yet implemented");
	}

	@Test
	public void testSearchNodes() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetWays() {
		fail("Not yet implemented");
	}

	@Test
	public void testSearchWays() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetRelations() {
		fail("Not yet implemented");
	}

	@Test
	public void testSearchRelations() {
		fail("Not yet implemented");
	}

	@Test
	public void testAllPrimitives() {
		fail("Not yet implemented");
	}

	@Test
	public void testAllNonDeletedPrimitives() {
		fail("Not yet implemented");
	}

	@Test
	public void testAllNonDeletedCompletePrimitives() {
		fail("Not yet implemented");
	}

	@Test
	public void testAllNonDeletedPhysicalPrimitives() {
		fail("Not yet implemented");
	}

	@Test
	public void testAllModifiedPrimitives() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddPrimitiveOsmPrimitive() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddPrimitivePrimitiveData() {
		fail("Not yet implemented");
	}

	@Test
	public void testRemovePrimitive() {
		fail("Not yet implemented");
	}

	@Test
	public void testFireSelectionChanged() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetSelectedNodesAndWays() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetSelected() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetSelectedNodes() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetSelectedWays() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetSelectedRelations() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsSelected() {
		fail("Not yet implemented");
	}

	@Test
	public void testToggleSelectedCollectionOfQextendsPrimitiveId() {
		fail("Not yet implemented");
	}

	@Test
	public void testToggleSelectedPrimitiveIdArray() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetSelectedCollectionOfQextendsPrimitiveIdBoolean() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetSelectedCollectionOfQextendsPrimitiveId() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetSelectedPrimitiveIdArray() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddSelectedCollectionOfQextendsPrimitiveId() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddSelectedPrimitiveIdArray() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddSelectedCollectionOfQextendsPrimitiveIdBoolean() {
		fail("Not yet implemented");
	}

	@Test
	public void testClearSelectionPrimitiveIdArray() {
		fail("Not yet implemented");
	}

	@Test
	public void testClearSelectionCollectionOfQextendsPrimitiveId() {
		fail("Not yet implemented");
	}

	@Test
	public void testClearSelection() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetDisabledOsmPrimitiveArray() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetDisabledCollectionOfQextendsOsmPrimitive() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetFilteredCollectionOfQextendsOsmPrimitive() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetFilteredOsmPrimitiveArray() {
		fail("Not yet implemented");
	}

	@Test
	public void testClone() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetDataSourceArea() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetPrimitiveByIdLongOsmPrimitiveType() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetPrimitiveByIdPrimitiveId() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetPrimitiveByIdPrimitiveIdBoolean() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteWay() {
		fail("Not yet implemented");
	}

	@Test
	public void testUnlinkNodeFromWays() {
		fail("Not yet implemented");
	}

	@Test
	public void testUnlinkPrimitiveFromRelations() {
		fail("Not yet implemented");
	}

	@Test
	public void testUnlinkReferencesToPrimitive() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsModified() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddDataSetListener() {
		fail("Not yet implemented");
	}

	@Test
	public void testRemoveDataSetListener() {
		fail("Not yet implemented");
	}

	@Test
	public void testBeginUpdate() {
		fail("Not yet implemented");
	}

	@Test
	public void testEndUpdate() {
		fail("Not yet implemented");
	}

	@Test
	public void testFirePrimitivesAdded() {
		fail("Not yet implemented");
	}

	@Test
	public void testFirePrimitivesRemoved() {
		fail("Not yet implemented");
	}

	@Test
	public void testFireTagsChanged() {
		fail("Not yet implemented");
	}

	@Test
	public void testFireRelationMembersChanged() {
		fail("Not yet implemented");
	}

	@Test
	public void testFireNodeMoved() {
		fail("Not yet implemented");
	}

	@Test
	public void testFireWayNodesChanged() {
		fail("Not yet implemented");
	}

	@Test
	public void testFireChangesetIdChanged() {
		fail("Not yet implemented");
	}

	@Test
	public void testFireHighlightingChanged() {
		fail("Not yet implemented");
	}

	@Test
	public void testClenupDeletedPrimitives() {
		fail("Not yet implemented");
	}

	@Test
	public void testClear() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddError() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetErrors() {
		fail("Not yet implemented");
	}

	@Test
	public void testClearErrors() {
		fail("Not yet implemented");
	}

	@Override
	public String getModuleName() {
		// TODO Auto-generated method stub
		//return "org.openstreetmap.gwt.tests.DataSetTest";
		return "org.openstreetmap.gwt.GWTOSMJUnit";
	}

}
