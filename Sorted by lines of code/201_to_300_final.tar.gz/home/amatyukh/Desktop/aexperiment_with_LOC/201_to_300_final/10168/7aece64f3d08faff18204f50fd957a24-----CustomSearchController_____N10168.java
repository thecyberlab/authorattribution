/*
 * aTunes 1.14.0
 * Copyright (C) 2006-2009 Alex Aranda, Sylvain Gaudard, Thomas Beckers and contributors
 *
 * See http://www.atunes.org/wiki/index.php?title=Contributing for information about contributors
 *
 * http://www.atunes.org
 * http://sourceforge.net/projects/atunes
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

package net.sourceforge.atunes.kernel.controllers.customsearch;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.DefaultComboBoxModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import net.sourceforge.atunes.gui.views.dialogs.CustomSearchDialog;
import net.sourceforge.atunes.kernel.ControllerProxy;
import net.sourceforge.atunes.kernel.controllers.model.DialogController;
import net.sourceforge.atunes.kernel.modules.search.EmptyRule;
import net.sourceforge.atunes.kernel.modules.search.SearchHandler;
import net.sourceforge.atunes.kernel.modules.search.SearchIndexNotAvailableException;
import net.sourceforge.atunes.kernel.modules.search.SearchQuerySyntaxException;
import net.sourceforge.atunes.kernel.modules.search.SearchResult;
import net.sourceforge.atunes.kernel.modules.search.SearchableObject;
import net.sourceforge.atunes.kernel.modules.search.SimpleRule;
import net.sourceforge.atunes.kernel.modules.search.SearchHandler.LogicalOperator;
import net.sourceforge.atunes.kernel.modules.state.ApplicationState;
import net.sourceforge.atunes.kernel.modules.visual.VisualHandler;
import net.sourceforge.atunes.utils.GuiUtils;
import net.sourceforge.atunes.utils.LanguageTool;

import org.jdesktop.swingx.combobox.ListComboBoxModel;

/**
 * CustomSearchDialog controller.
 */
public class CustomSearchController extends DialogController<CustomSearchDialog> {

    /** List of searchable objects. */
    private List<SearchableObject> searchableObjects;

    /** Translated attributes */
    private Map<String, String> translatedAttributes = new HashMap<String, String>();

    /**
     * Constructor.
     * 
     * @param dialog
     *            the dialog
     */
    public CustomSearchController(CustomSearchDialog dialog) {
        super(dialog);
        addBindings();
    }

    /**
     * Shows dialog (previous values are cleared).
     */
    public void showSearchDialog() {
        ((DefaultTreeModel) getDialogControlled().getComplexRulesTree().getModel()).setRoot(null);
        getDialogControlled().getSimpleRulesComboBox().setSelectedIndex(0);
        getDialogControlled().getSimpleRulesTextField().setText("");
        getDialogControlled().getAdvancedSearchCheckBox().setSelected(ApplicationState.getInstance().isEnableAdvancedSearch());
        enableAdvancedSearch(ApplicationState.getInstance().isEnableAdvancedSearch());
        getDialogControlled().getAdvancedSearchTextField().setText("");
        getDialogControlled().setVisible(true);
    }

    /**
     * Fills combo box with list of objects where it's possible to search.
     * 
     * @param sObjects
     *            the s objects
     */
    public void setListOfSearchableObjects(List<SearchableObject> sObjects) {
        if (!sObjects.isEmpty()) {
            // Create list of names of searchable objects
            List<String> names = new ArrayList<String>();
            for (SearchableObject o : sObjects) {
                names.add(o.getSearchableObjectName());
            }
            getDialogControlled().getSearchAtComboBox().setModel(new ListComboBoxModel<String>(names));
            this.searchableObjects = sObjects;

            // Fire select event
            getDialogControlled().getSearchAtComboBox().setSelectedIndex(0);
        }
    }

    /**
     * Fills combo box with list of operators.
     * 
     * @param operators
     *            the operators
     */
    public void setListOfOperators(List<String> operators) {
        getDialogControlled().getSimpleRulesComboBox().setModel(new DefaultComboBoxModel(operators.toArray()));
    }

    /**
     * Displays attributes of selected searchable object.
     */
    public void updateAttributesList() {
        if (searchableObjects != null) {
            // Get selected searchable object
            SearchableObject selectedSearchableObject = searchableObjects.get(getDialogControlled().getSearchAtComboBox().getSelectedIndex());

            // Get attributes
            List<String> attributes = selectedSearchableObject.getSearchableAttributes();
            attributes.add(0, SearchHandler.DEFAULT_INDEX);

            // Translate attributes to locale
            List<String> translatedAttributesList = new ArrayList<String>();
            for (String attr : attributes) {
                String translatedAttribute = LanguageTool.getString(attr.toUpperCase());
                translatedAttributesList.add(translatedAttribute);
                translatedAttributes.put(translatedAttribute, attr);
            }

            // Set attributes list
            getDialogControlled().getSimpleRulesList().setListData(translatedAttributesList.toArray());
        }
    }

    /**
     * Creates a simple rule.
     */
    public void createSimpleRule() {
        // Get simple rule data: attribute, operator and value
        String attribute = (String) getDialogControlled().getSimpleRulesList().getSelectedValue();
        String operator = (String) getDialogControlled().getSimpleRulesComboBox().getSelectedItem();
        String value = getDialogControlled().getSimpleRulesTextField().getText();

        // Create object
        SimpleRule simpleRule = new SimpleRule(attribute, operator, value);

        // Add simple rule to tree
        DefaultTreeModel model = ((DefaultTreeModel) getDialogControlled().getComplexRulesTree().getModel());
        DefaultMutableTreeNode rootNode = (DefaultMutableTreeNode) getDialogControlled().getComplexRulesTree().getModel().getRoot();

        DefaultMutableTreeNode node = new DefaultMutableTreeNode(simpleRule);

        // Rule is empty, new simple rule is root
        if (rootNode == null) {
            model.setRoot(node);
        } else {
            // Rule is not empty, get selected node
            DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) getDialogControlled().getComplexRulesTree().getSelectionPath().getLastPathComponent();

            // If selected node is an empty rule replace it
            if (selectedNode.getUserObject() instanceof EmptyRule) {
                selectedNode.setUserObject(simpleRule);
            } else {
                // If it's not an empty rule, then add as child
                selectedNode.add(node);
            }
        }

        // Reload model
        model.reload();

        // Update advanced search text field
        updateAdvancedSearchTextField();

        // Expand complex rules tree to display full rule
        GuiUtils.expandTree(getDialogControlled().getComplexRulesTree());
    }

    /**
     * Adds AND operator to rule.
     */
    public void addAndOperator() {
        addLogicalOperator(LogicalOperator.AND);
    }

    /**
     * Adds OR operator to rule.
     */
    public void addOrOperator() {
        addLogicalOperator(LogicalOperator.OR);
    }

    /**
     * Adds NOT operator to rule.
     */
    public void addNotOperator() {
        addLogicalOperator(LogicalOperator.NOT);
    }

    /**
     * Generic method to add a logical operator to rule.
     * 
     * @param operator
     *            the operator
     */
    private void addLogicalOperator(LogicalOperator operator) {
        // Get selected node and parent
        DefaultTreeModel model = ((DefaultTreeModel) getDialogControlled().getComplexRulesTree().getModel());
        DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) getDialogControlled().getComplexRulesTree().getSelectionPath().getLastPathComponent();
        DefaultMutableTreeNode parentNode = (DefaultMutableTreeNode) selectedNode.getParent();

        // Create node
        DefaultMutableTreeNode logicalNode = new DefaultMutableTreeNode(operator);

        // Node is root
        if (parentNode == null) {
            // add as root
            model.setRoot(logicalNode);
        } else {
            // add as child of parent
            parentNode.add(logicalNode);
            parentNode.remove(selectedNode);

        }
        // Add previous selected node as child of new logical operator node
        logicalNode.add(selectedNode);

        // If operator is AND, OR, then add a second child (an empty rule) as these operators are binary
        if (!operator.equals(LogicalOperator.NOT)) {
            DefaultMutableTreeNode secondOperand = new DefaultMutableTreeNode(new EmptyRule());
            logicalNode.add(secondOperand);
        }

        // Reload model
        model.reload();

        // Update advanced search text field
        updateAdvancedSearchTextField();

        // Expand complex rules tree to display full rule
        GuiUtils.expandTree(getDialogControlled().getComplexRulesTree());
    }

    /**
     * Updated advanced search text field with rule tree content.
     */
    private void updateAdvancedSearchTextField() {
        DefaultMutableTreeNode node = (DefaultMutableTreeNode) getDialogControlled().getComplexRulesTree().getModel().getRoot();
        String query = "";
        if (node != null) {
            query = createQuery(node);
        }
        getDialogControlled().getAdvancedSearchTextField().setText(query);
    }

    /**
     * Recursive method to create a string representation of a complex rule.
     * 
     * @param node
     *            the node
     * 
     * @return the string
     */
    private String createQuery(DefaultMutableTreeNode node) {
        // Node is leaf, return it as string
        if (node.isLeaf()) {
            return node.getUserObject().toString();
        }

        StringBuilder sb = new StringBuilder();
        sb.append("(");
        // If it's a NOT then return (NOT xx)
        if (node.getUserObject().equals(LogicalOperator.NOT)) {
            sb.append(node.getUserObject());
            sb.append(" ");
            sb.append(createQuery((DefaultMutableTreeNode) node.getChildAt(0)));
        } else {
            // If it's not a NOT, then return (xx OP yy OP zz ...)
            for (int i = 0; i < node.getChildCount() - 1; i++) {
                sb.append(createQuery((DefaultMutableTreeNode) node.getChildAt(i)));
                sb.append(" ");
                sb.append(node.toString());
                sb.append(" ");
            }
            sb.append(createQuery((DefaultMutableTreeNode) node.getChildAt(node.getChildCount() - 1)));
        }
        sb.append(")");
        return sb.toString();
    }

    /**
     * Removes a node from rule tree.
     */
    public void removeRuleNode() {
        // Get selected node and parent
        DefaultTreeModel model = ((DefaultTreeModel) getDialogControlled().getComplexRulesTree().getModel());
        DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) getDialogControlled().getComplexRulesTree().getSelectionPath().getLastPathComponent();
        DefaultMutableTreeNode parentNode = (DefaultMutableTreeNode) selectedNode.getParent();

        // If it's root, remove it
        if (selectedNode.isRoot()) {
            model.setRoot(null);
            // Allow user to add more simple rules
            getDialogControlled().getSimpleRulesAddButton().setEnabled(true);
        } else {
            // If it's not root, if parent has more than 2 children, then remove it (to keep binary operators with 2 childs at least)
            if (parentNode.getChildCount() > 2) {
                parentNode.remove(selectedNode);
            } else {
                // parent has 2 children, replace and if it's not a simple rule, remove its children
                selectedNode.setUserObject(new EmptyRule());
                if (!(selectedNode.getUserObject() instanceof SimpleRule)) {
                    selectedNode.removeAllChildren();
                }
            }
        }

        // Reload model
        model.reload();

        // Update advanced search text field
        updateAdvancedSearchTextField();

        // Expand complex rules tree to display full rule
        GuiUtils.expandTree(getDialogControlled().getComplexRulesTree());
    }

    /**
     * Replace attributes from translated string to internal string
     * 
     * @param query
     * @return
     */
    private String translateQuery(String query) {
        List<String> translatedAttributesList = new ArrayList<String>(translatedAttributes.keySet());

        // Sort translated attributes from the largest to the smallest, to apply substitution in correct order
        Collections.sort(translatedAttributesList, new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                return -Integer.valueOf(o1.length()).compareTo(Integer.valueOf(o2.length()));
            }
        });

        String translatedQuery = query;
        // Replace translated attributes to internal
        for (String translatedAttr : translatedAttributesList) {
            translatedQuery = translatedQuery.replaceAll(translatedAttr, translatedAttributes.get(translatedAttr));
        }

        return translatedQuery;
    }

    /**
     * Invokes a search with rule defined in dialog.
     */
    public void search() {
        if (searchableObjects != null) {
            // Get searchable object
            SearchableObject selectedSearchableObject = searchableObjects.get(getDialogControlled().getSearchAtComboBox().getSelectedIndex());

            // Get query: as advanced search text field is updated with tree rules, we can always get query from this text field
            String query = getDialogControlled().getAdvancedSearchTextField().getText();

            // Translate query to internal attribute names
            query = translateQuery(query);

            try {
                // Invoke query
                List<SearchResult> result = SearchHandler.getInstance().search(selectedSearchableObject, query);

                // If no matches found show a message
                if (result.isEmpty()) {
                    VisualHandler.getInstance().showMessage(LanguageTool.getString("NO_MATCHES_FOUND"));
                } else {
                    // Show result
                    showSearchResults(selectedSearchableObject, result);
                }
            } catch (SearchIndexNotAvailableException e) {
                // Thrown when an attribute does not exist on index
                VisualHandler.getInstance().showErrorDialog(LanguageTool.getString("INVALID_SEARCH_RULE"));
            } catch (SearchQuerySyntaxException e) {
                // Thrown when query has invalid syntax
                VisualHandler.getInstance().showErrorDialog(LanguageTool.getString("INVALID_SEARCH_RULE"));
            }
        } else {
            VisualHandler.getInstance().showMessage(LanguageTool.getString("NO_MATCHES_FOUND"));
        }
    }

    /**
     * Called to show search result.
     * 
     * @param searchableObject
     *            the searchable object
     * @param result
     *            the result
     */
    private void showSearchResults(SearchableObject searchableObject, List<SearchResult> result) {
        // Hide search dialog
        getDialogControlled().setVisible(false);
        // Open search results dialog
        ControllerProxy.getInstance().getSearchResultsController().showSearchResults(searchableObject, result);
    }

    /**
     * Enables or disables advanced search.
     * 
     * @param enable
     *            the enable
     */
    public void enableAdvancedSearch(boolean enable) {
        getDialogControlled().getSimpleRulesAddButton().setEnabled(!enable);
        getDialogControlled().getSimpleRulesComboBox().setEnabled(!enable);
        getDialogControlled().getSimpleRulesList().setEnabled(!enable);
        getDialogControlled().getSimpleRulesTextField().setEnabled(!enable);
        getDialogControlled().getComplexRulesAndButton().setEnabled(!enable);
        getDialogControlled().getComplexRulesOrButton().setEnabled(!enable);
        getDialogControlled().getComplexRulesNotButton().setEnabled(!enable);
        getDialogControlled().getComplexRulesRemoveButton().setEnabled(!enable);
        getDialogControlled().getComplexRulesTree().setEnabled(!enable);
        getDialogControlled().getAdvancedSearchTextField().setEnabled(enable);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * net.sourceforge.atunes.kernel.controllers.model.Controller#addBindings()
     */
    @Override
    protected void addBindings() {
        CustomSearchListener listener = new CustomSearchListener(getDialogControlled());
        getDialogControlled().getSearchAtComboBox().addActionListener(listener);
        getDialogControlled().getSimpleRulesAddButton().addActionListener(listener);
        getDialogControlled().getComplexRulesTree().setModel(new DefaultTreeModel(null));
        getDialogControlled().getComplexRulesAndButton().addActionListener(listener);
        getDialogControlled().getComplexRulesOrButton().addActionListener(listener);
        getDialogControlled().getComplexRulesNotButton().addActionListener(listener);
        getDialogControlled().getComplexRulesRemoveButton().addActionListener(listener);
        getDialogControlled().getAdvancedSearchCheckBox().addActionListener(listener);
        getDialogControlled().getSearchButton().addActionListener(listener);
        ComplexTreeSelectionListener selListener = new ComplexTreeSelectionListener(getDialogControlled(), getDialogControlled().getComplexRulesTree());
        getDialogControlled().getComplexRulesTree().addTreeSelectionListener(selListener);
        getDialogControlled().getCancelButton().addActionListener(listener);
        getDialogControlled().getAdvancedSearchTextField().addActionListener(listener);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * net.sourceforge.atunes.kernel.controllers.model.Controller#addStateBindings
     * ()
     */
    @Override
    protected void addStateBindings() {
        // Nothing to do
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * net.sourceforge.atunes.kernel.controllers.model.Controller#notifyReload()
     */
    @Override
    protected void notifyReload() {
        // Nothing to do
    }

}
