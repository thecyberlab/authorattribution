class CreateImpl {
	int execute(String LastName, String FirstName ) {
  // Begin Protected Region [[]]
                
  // End Protected Region   [[]]
	}
}
// Actifsource ID=[88a71515-8c69-11df-a65f-fd4c167633ca,41121bc5-8c67-11df-a65f-fd4c167633ca,4505c429-8c67-11df-a65f-fd4c167633ca]
