class DeleteImpl {
	boolean execute(int Id ) {
  // Begin Protected Region [[]]
                
  // End Protected Region   [[]]
	}
}
// Actifsource ID=[88a71515-8c69-11df-a65f-fd4c167633ca,41121bc5-8c67-11df-a65f-fd4c167633ca,6eb415d3-8c67-11df-a65f-fd4c167633ca]
