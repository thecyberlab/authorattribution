class PatientImpl {
	public int Create(String LastName, String FirstName ) {
  // Begin Protected Region [[ce1ac355-8b4c-11df-abce-ffdcfaccc0b3]]
                return 23;     
  // End Protected Region   [[ce1ac355-8b4c-11df-abce-ffdcfaccc0b3]]
	}
	public boolean Delete(int Id ) {
  // Begin Protected Region [[84d2c671-8b4e-11df-abce-ffdcfaccc0b3]]
                return true;       
  // End Protected Region   [[84d2c671-8b4e-11df-abce-ffdcfaccc0b3]]
	}
}
// Actifsource ID=[0852de8a-8b4f-11df-abce-ffdcfaccc0b3,bb1c65b1-8b4c-11df-abce-ffdcfaccc0b3]
