package com.actifsource.simpleservice.template;

import java.util.List;

/* Begin Protected Region [[0846a951-8b4f-11df-abce-ffdcfaccc0b3,imports]] */

/* End Protected Region   [[0846a951-8b4f-11df-abce-ffdcfaccc0b3,imports]] */

@SuppressWarnings("unused")
public class ServiceImpl {

  /* Begin Protected Region [[0846a951-8b4f-11df-abce-ffdcfaccc0b3]] */
  
  /* End Protected Region   [[0846a951-8b4f-11df-abce-ffdcfaccc0b3]] */


}

/* Actifsource ID=[5349246f-db37-11de-82b8-17be2e034a3b,0846a951-8b4f-11df-abce-ffdcfaccc0b3] */
