package com.actifsource.projectgenerator.spec;

import java.util.List;

/* Begin Protected Region [[0e19ffbe-8e65-11df-88d6-a50cae917c2c,imports]] */

/* End Protected Region   [[0e19ffbe-8e65-11df-88d6-a50cae917c2c,imports]] */

@SuppressWarnings("unused")
public class ProjectConfigTemplate {

  /* Begin Protected Region [[0e19ffbe-8e65-11df-88d6-a50cae917c2c]] */
  
  /* End Protected Region   [[0e19ffbe-8e65-11df-88d6-a50cae917c2c]] */


}

/* Actifsource ID=[5349246f-db37-11de-82b8-17be2e034a3b,0e19ffbe-8e65-11df-88d6-a50cae917c2c] */
