package com.actifsource.projectgenerator.spec;

import java.util.List;

/* Begin Protected Region [[3896f306-8e62-11df-88d6-a50cae917c2c,imports]] */

/* End Protected Region   [[3896f306-8e62-11df-88d6-a50cae917c2c,imports]] */

@SuppressWarnings("unused")
public class ProjectSettingsTemplate {

  /* Begin Protected Region [[3896f306-8e62-11df-88d6-a50cae917c2c]] */
  
  /* End Protected Region   [[3896f306-8e62-11df-88d6-a50cae917c2c]] */


}

/* Actifsource ID=[5349246f-db37-11de-82b8-17be2e034a3b,3896f306-8e62-11df-88d6-a50cae917c2c] */
