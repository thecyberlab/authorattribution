package xtc.lang.c4.advice;

/**
 * The different states for the advice.
 * 
 * @author Marco Yuen
 * @version $Revision: 1.1 $
 */
public enum C4AdviceState {
  TRANSFORMED, NEW
}
