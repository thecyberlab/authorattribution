package com.wee.mis;

/**
 * Created by IntelliJ IDEA.
 * User: Administrator
 * Date: 2009-11-3
 * Time: 21:01:05
 * To change this template use File | Settings | File Templates.
 */
public class Hanoi {

    public Hanoi(int i) {
        //To change body of created methods use File | Settings | File Templates.
    }

    public int steps() {
        return 7;  //To change body of created methods use File | Settings | File Templates.
    }
}
