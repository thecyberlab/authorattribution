package com.wee.mvc;

/**
 * User: weejulius
 * Date: 2009-7-26
 * Time: 20:23:02
 */
public class Forward {
    public Forward() {
    }

    public Forward(Object arg) {
    }

    public Forward(Object argOne, Object argTwo) {

    }

    public Forward(Object[] args) {

    }

    public void goTo(URLMappingAndView URLMappingAndView) {

    }

    public void abortAndgoTo(URLMappingAndView URLMappingAndView) {

    }
}
