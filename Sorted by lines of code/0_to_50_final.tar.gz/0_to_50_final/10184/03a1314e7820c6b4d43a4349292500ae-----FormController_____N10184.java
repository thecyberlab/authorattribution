package com.wee.mvc;

/**
 * User: weejulius
 * Date: 2009-7-28
 * Time: 10:05:58
 */
public class FormController {
}
