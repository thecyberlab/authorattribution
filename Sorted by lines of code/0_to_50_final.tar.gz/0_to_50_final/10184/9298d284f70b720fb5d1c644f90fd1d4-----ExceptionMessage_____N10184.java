package com.wee.voyages.application.validatation;

/**
 * User: weejulius
 * Date: 2009-7-26
 * Time: 21:38:09
 */
public class ExceptionMessage {
}
