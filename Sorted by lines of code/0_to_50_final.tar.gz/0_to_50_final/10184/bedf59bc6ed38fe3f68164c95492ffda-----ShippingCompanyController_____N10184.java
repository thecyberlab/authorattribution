package com.wee.voyages.interfaces.voyage.controller;

/**
 * User: weejulius
 * Date: 2009-7-26
 * Time: 11:13:36
 */
public class ShippingCompanyController {
}
