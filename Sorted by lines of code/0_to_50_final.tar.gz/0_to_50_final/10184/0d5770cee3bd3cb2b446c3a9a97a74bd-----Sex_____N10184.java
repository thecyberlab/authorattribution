package com.wee.voyages.domain.model.customer;

/**
 * User: weejulius
 * Date: 2009-7-10
 * Time: 17:00:46
 */
public enum Sex {
    female,male;
}
