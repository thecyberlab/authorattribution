package com.wee.voyages.application.validatation;

/**
 * User: weejulius
 * Date: 2009-7-25
 * Time: 8:26:10
 */
public class UnBrokenRuleException implements RuleException {
    public UnBrokenRuleException(String message) {
    }
}
