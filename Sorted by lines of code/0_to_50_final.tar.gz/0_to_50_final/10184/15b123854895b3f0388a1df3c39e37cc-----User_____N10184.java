package com.wee.voyages.domain.model.user;

/**
 * User: weejulius
 * Date: 2009-7-10
 * Time: 15:38:55
 */
public interface User {
    
}
