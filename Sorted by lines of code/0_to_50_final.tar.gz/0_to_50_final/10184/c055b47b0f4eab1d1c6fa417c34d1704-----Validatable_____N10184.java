package com.wee.voyages.application.validatation;

/**
 * User: weejulius
 * Date: 2009-7-26
 * Time: 19:40:17
 */
public interface Validatable {
    void validate();
}
