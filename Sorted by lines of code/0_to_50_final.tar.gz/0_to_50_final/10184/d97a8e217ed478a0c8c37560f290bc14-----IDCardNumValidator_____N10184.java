package com.wee.voyages.domain.model.customer;

/**
 * User: weejulius
 * Date: 2009-7-21
 * Time: 20:55:11
 */
public class IDCardNumValidator {
    public boolean isValid(IDCardNum num){
        return false;
    }
}
