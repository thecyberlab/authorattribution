package com.wee.voyages.domain.model.inspecting;

import com.wee.voyages.domain.model.customer.Customer;

/**
 * User: weejulius
 * Date: 2009-7-13
 * Time: 9:23:09
 */
public interface RuleRepository {
   
}
