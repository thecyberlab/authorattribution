package com.wee.mvc;

/**
 * User: weejulius
 * Date: 2009-7-30
 * Time: 20:36:43
 */
public enum CLIUD {
    ERROR,CREATE,LIST,INDEX,UPDATE,DELETE ;

}
