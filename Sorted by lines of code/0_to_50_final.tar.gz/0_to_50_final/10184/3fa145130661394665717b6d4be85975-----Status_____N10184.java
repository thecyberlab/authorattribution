package com.wee.voyages.domain.model.voyage;

/**
 * User: weejulius
 * Date: 2009-7-10
 * Time: 15:14:14
 */
public enum Status {
    Init,Started,End;
}
