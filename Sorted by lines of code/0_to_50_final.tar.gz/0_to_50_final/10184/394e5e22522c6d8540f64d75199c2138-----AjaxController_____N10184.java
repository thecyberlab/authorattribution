package com.wee.mvc;

/**
 * User: weejulius
 * Date: 2009-7-28
 * Time: 10:05:47
 */
public class AjaxController {
}
