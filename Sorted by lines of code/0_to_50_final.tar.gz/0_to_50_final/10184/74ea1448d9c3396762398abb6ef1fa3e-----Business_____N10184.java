package com.wee.mvc;

/**
 * User: weejulius
 * Date: 2009-7-28
 * Time: 10:18:27
 */
public class Business {
    public static void select(String s) {

    }

    public static void works(String s) {

    }
}
