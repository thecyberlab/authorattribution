package com.wee.voyages;

import org.junit.Test;

/**
 * Created by IntelliJ IDEA.
 * User: Administrator
 * Date: 2009-11-3
 * Time: 19:46:23
 * To change this template use File | Settings | File Templates.
 */
public class PrimitiveCastTest {
   @Test
    public void intToLongTest(){
       long a=123;
   }
}
