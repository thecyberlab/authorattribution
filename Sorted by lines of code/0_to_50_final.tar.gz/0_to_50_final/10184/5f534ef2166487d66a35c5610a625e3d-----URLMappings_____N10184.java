package com.wee.mvc;

/**
 * User: weejulius
 * Date: 2009-7-31
 * Time: 16:40:08
 */
public class URLMappings {

}
