package com.wee.mvc;

import javax.servlet.*;
import java.io.IOException;

/**
 * User: weejulius
 * Date: 2009-7-28
 * Time: 12:03:02
 */
public class URLFilter implements Filter {
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
            
    }

    public void destroy() {

    }
}
