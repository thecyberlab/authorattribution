package com.wee.voyages.application.validatation;

/**
 * User: weejulius
 * Date: 2009-7-23
 * Time: 22:03:49
 */
public class BrokenException extends Exception {
    public BrokenException(String message) {
        super(message);
    }
}
