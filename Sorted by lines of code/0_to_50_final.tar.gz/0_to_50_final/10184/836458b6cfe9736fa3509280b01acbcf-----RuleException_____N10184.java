package com.wee.voyages.application.validatation;

/**
 * User: weejulius
 * Date: 2009-7-25
 * Time: 8:15:32
 */
public interface RuleException {
}
