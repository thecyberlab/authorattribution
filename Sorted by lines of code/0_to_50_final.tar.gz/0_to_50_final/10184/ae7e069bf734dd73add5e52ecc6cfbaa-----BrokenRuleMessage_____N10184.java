package com.wee.voyages.application.validatation;

/**
 * User: weejulius
 * Date: 2009-7-28
 * Time: 9:04:51
 */
public class BrokenRuleMessage {
}
