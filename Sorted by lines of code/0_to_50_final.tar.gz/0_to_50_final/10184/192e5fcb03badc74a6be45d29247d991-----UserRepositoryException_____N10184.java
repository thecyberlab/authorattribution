package com.wee.netnotes.domain.user;

public class UserRepositoryException extends RuntimeException{

}
