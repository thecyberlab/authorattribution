package com.usemodj.blog.domain;

public class DraftPost extends Post {
}
