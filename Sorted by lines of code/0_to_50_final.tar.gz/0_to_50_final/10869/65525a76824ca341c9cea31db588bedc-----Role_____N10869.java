package com.usemodj.struts;

public enum Role {
	ADMIN,MANAGER,GENERAL
}
