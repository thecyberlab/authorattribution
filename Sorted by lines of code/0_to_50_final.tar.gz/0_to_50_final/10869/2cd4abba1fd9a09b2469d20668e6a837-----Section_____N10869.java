package com.usemodj.blog.domain;

import java.io.Serializable;

public enum Section implements Serializable {
  NEWS, VIDEOS, IMAGES, PODCASTS
}
