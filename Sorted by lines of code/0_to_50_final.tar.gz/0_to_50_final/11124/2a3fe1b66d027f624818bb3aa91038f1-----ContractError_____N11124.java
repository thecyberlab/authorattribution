package com.todesking.sandbox.contract;

public class ContractError extends Error {
	private static final long serialVersionUID = 1L;

	public ContractError(String message) {
		super(message);
	}

}
