package jboost.tokenizer;

public class SpecFileException extends ParseException {

  public SpecFileException(String m) {
    super(m);
  }
}
