/*
 * Created on Feb 9, 2004
 */
package jboost.learner;

import junit.framework.TestCase;

/**
 * @author cschavis
 */
public class SetSplitterBuilderTest extends TestCase {

  SetSplitterBuilder m_builder;

  /*
   * @see TestCase#setUp()
   */
  protected void setUp() throws Exception {
    super.setUp();
  }

  /*
   * @see TestCase#tearDown()
   */
  protected void tearDown() throws Exception {
    super.tearDown();
  }

  /*
   * Class to test for CandidateSplit build()
   */
  public void testBuild() {
    // TODO Implement build().
  }

  /*
   * Class to test for CandidateSplit build(Splitter)
   */
  public void testBuildSplitter() {
    // TODO Implement build().
  }

  public void testSplit() {
    // TODO Implement split().
  }

  public void testAddExample() {
    // TODO Implement addExample().
  }

}
