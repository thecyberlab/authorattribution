package reinforcement.worlds;

/**
 * Created by IntelliJ IDEA.
 * User: adenysenko
 * Date: Jul 28, 2009
 * Time: 6:11:59 PM
 * To change this template use File | Settings | File Templates.
 */
public interface RState {
}
