package audio.cords;

/**
 * Created by IntelliJ IDEA.
 * User: adenysenko
 * Date: Dec 3, 2009
 * Time: 4:20:46 PM
 * To change this template use File | Settings | File Templates.
 */
public interface SoundIn {
  short next();
}
