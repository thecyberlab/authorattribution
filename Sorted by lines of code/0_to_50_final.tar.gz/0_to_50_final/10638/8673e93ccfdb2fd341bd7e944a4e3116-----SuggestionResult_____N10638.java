package logic;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: adenysenko
 * Date: Mar 12, 2009
 * Time: 5:21:15 PM
 * To change this template use File | Settings | File Templates.
 */
public class SuggestionResult {
  CmdSet cmdSet;
  List<String> csFiltered;
}
