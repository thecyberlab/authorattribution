package mem;

/**
 * Created by IntelliJ IDEA.
 * User: adenysenko
 * Date: 4/4/2008
 * Time: 18:34:01
 */
public interface ViewDepthIterator {

  ViewDepth next();
}
